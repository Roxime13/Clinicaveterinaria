

function HeaderClinica(){
    return (
    <div className="md:text-center">
      <h1 className="text-center p-3 bg-primary text-white m-auto me-0">Clínica Goodhealth</h1>
      </div>
    );
  }
export default HeaderClinica




